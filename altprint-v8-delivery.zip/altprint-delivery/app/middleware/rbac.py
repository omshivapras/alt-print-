from fastapi import Depends, HTTPException
from app.middleware.auth import get_current_user
from app.models import User, UserRole

def admin_only(user: User = Depends(get_current_user)) -> User:
    if user.role != UserRole.admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return user

def shop_only(user: User = Depends(get_current_user)) -> User:
    if user.role not in [UserRole.admin, UserRole.shop]:
        raise HTTPException(status_code=403, detail="Shop or admin access required")
    return user

def user_or_shop(user: User = Depends(get_current_user)) -> User:
    if user.role not in [UserRole.admin, UserRole.shop, UserRole.user]:
        raise HTTPException(status_code=403, detail="Access denied")
    return user
