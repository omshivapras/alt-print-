"""
ALTPrint — Database Models
All tables: User, Zone, Hub, Agent, DeliveryPartner, PrintOrder, OrderFile, Payment, Feature
"""
from sqlalchemy import (
    Column, Integer, String, Boolean, Float, DateTime, Text,
    ForeignKey, Enum as SAEnum
)
from sqlalchemy.orm import relationship, declarative_base
from datetime import datetime
import enum

Base = declarative_base()


# ── ENUMS ─────────────────────────────────────────────────────────────────

class UserRole(str, enum.Enum):
    admin  = "admin"
    shop   = "shop"
    user   = "user"
    agent  = "agent"

class ZoneStatus(str, enum.Enum):
    active   = "active"
    inactive = "inactive"

class OrderStatus(str, enum.Enum):
    pending     = "pending"
    processing  = "processing"
    ready       = "ready"
    out_for_delivery = "out_for_delivery"
    delivered   = "delivered"
    cancelled   = "cancelled"

class PaymentStatus(str, enum.Enum):
    pending = "pending"
    paid    = "paid"
    failed  = "failed"

class DeliveryStatus(str, enum.Enum):
    idle      = "idle"
    assigned  = "assigned"
    picked_up = "picked_up"
    on_route  = "on_route"
    delivered = "delivered"


# ── USER ──────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(100), nullable=False)
    email       = Column(String(150), unique=True, index=True, nullable=False)
    phone       = Column(String(15), unique=True, index=True, nullable=False)
    password    = Column(String(255), nullable=False)
    role        = Column(SAEnum(UserRole), default=UserRole.user, nullable=False)
    zone_id     = Column(Integer, ForeignKey("zones.id"), nullable=True)
    permissions = Column(Text, default="[]")   # JSON list of permission strings
    is_active   = Column(Boolean, default=True)
    created_at  = Column(DateTime, default=datetime.utcnow)

    zone        = relationship("Zone", back_populates="users", foreign_keys=[zone_id])
    orders      = relationship("PrintOrder", back_populates="user")
    files       = relationship("OrderFile", back_populates="user")


# ── ZONE ──────────────────────────────────────────────────────────────────

class Zone(Base):
    __tablename__ = "zones"

    id                   = Column(Integer, primary_key=True, index=True)
    name                 = Column(String(100), nullable=False)
    center_lat           = Column(Float, nullable=False)
    center_lng           = Column(Float, nullable=False)
    radius_km            = Column(Float, default=5.0)
    status               = Column(SAEnum(ZoneStatus), default=ZoneStatus.inactive)
    is_accepting_orders  = Column(Boolean, default=True)
    created_at           = Column(DateTime, default=datetime.utcnow)

    users    = relationship("User", back_populates="zone", foreign_keys=[User.zone_id])
    hubs     = relationship("Hub", back_populates="zone")
    orders   = relationship("PrintOrder", back_populates="zone")
    delivery_partners = relationship("DeliveryPartner", back_populates="zone")

    @property
    def can_accept_orders(self):
        return self.status == ZoneStatus.active and self.is_accepting_orders


# ── HUB ───────────────────────────────────────────────────────────────────

class Hub(Base):
    __tablename__ = "hubs"

    id         = Column(Integer, primary_key=True, index=True)
    name       = Column(String(100), nullable=False)
    zone_id    = Column(Integer, ForeignKey("zones.id"), nullable=False)
    address    = Column(String(255), nullable=True)
    lat        = Column(Float, nullable=True)
    lng        = Column(Float, nullable=True)
    is_active  = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    zone    = relationship("Zone", back_populates="hubs")
    agents  = relationship("Agent", back_populates="hub")
    orders  = relationship("PrintOrder", back_populates="hub")
    delivery_partners = relationship("DeliveryPartner", back_populates="hub")


# ── AGENT (Shop Staff) ────────────────────────────────────────────────────

class Agent(Base):
    __tablename__ = "agents"

    id         = Column(Integer, primary_key=True, index=True)
    name       = Column(String(100), nullable=False)
    phone      = Column(String(15), unique=True, nullable=False)
    email      = Column(String(150), unique=True, nullable=False)
    password   = Column(String(255), nullable=False)
    hub_id     = Column(Integer, ForeignKey("hubs.id"), nullable=False)
    zone_id    = Column(Integer, ForeignKey("zones.id"), nullable=False)
    is_active  = Column(Boolean, default=True)
    is_online  = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    hub    = relationship("Hub", back_populates="agents")
    orders = relationship("PrintOrder", back_populates="agent")


# ── DELIVERY PARTNER ──────────────────────────────────────────────────────

class DeliveryPartner(Base):
    __tablename__ = "delivery_partners"

    id              = Column(Integer, primary_key=True, index=True)
    name            = Column(String(100), nullable=False)
    phone           = Column(String(15), unique=True, nullable=False)
    email           = Column(String(150), unique=True, nullable=True)
    password        = Column(String(255), nullable=False)
    vehicle_type    = Column(String(50), nullable=True)   # bike, scooter, cycle
    vehicle_number  = Column(String(20), nullable=True)
    zone_id         = Column(Integer, ForeignKey("zones.id"), nullable=True)
    hub_id          = Column(Integer, ForeignKey("hubs.id"), nullable=True)

    # Live location — updated when on delivery
    current_lat     = Column(Float, nullable=True)
    current_lng     = Column(Float, nullable=True)
    last_location_update = Column(DateTime, nullable=True)

    # Status
    is_active       = Column(Boolean, default=True)
    is_online       = Column(Boolean, default=False)      # logged in & available
    is_on_delivery  = Column(Boolean, default=False)
    delivery_status = Column(SAEnum(DeliveryStatus), default=DeliveryStatus.idle)

    # Documents (stored as filenames)
    aadhar_file     = Column(String(255), nullable=True)
    license_file    = Column(String(255), nullable=True)
    photo_file      = Column(String(255), nullable=True)

    created_at      = Column(DateTime, default=datetime.utcnow)

    zone    = relationship("Zone", back_populates="delivery_partners")
    hub     = relationship("Hub", back_populates="delivery_partners")
    deliveries = relationship("PrintOrder", back_populates="delivery_partner")


# ── PRINT ORDER ───────────────────────────────────────────────────────────

class PrintOrder(Base):
    __tablename__ = "print_orders"

    id                = Column(Integer, primary_key=True, index=True)
    order_ref         = Column(String(20), unique=True, index=True)   # XR-20240001
    user_id           = Column(Integer, ForeignKey("users.id"), nullable=False)
    zone_id           = Column(Integer, ForeignKey("zones.id"), nullable=True)
    hub_id            = Column(Integer, ForeignKey("hubs.id"), nullable=True)
    agent_id          = Column(Integer, ForeignKey("agents.id"), nullable=True)
    delivery_partner_id = Column(Integer, ForeignKey("delivery_partners.id"), nullable=True)

    # Order details
    status            = Column(SAEnum(OrderStatus), default=OrderStatus.pending)
    total_price       = Column(Float, default=0.0)
    payment_status    = Column(SAEnum(PaymentStatus), default=PaymentStatus.pending)

    # Delivery
    delivery_mode     = Column(String(20), default="pickup")   # pickup | delivery
    delivery_address  = Column(Text, nullable=True)
    delivery_lat      = Column(Float, nullable=True)
    delivery_lng      = Column(Float, nullable=True)
    delivery_cost     = Column(Float, default=0.0)

    # User location at time of order
    user_lat          = Column(Float, nullable=True)
    user_lng          = Column(Float, nullable=True)

    # Razorpay
    razorpay_order_id   = Column(String(100), nullable=True)
    razorpay_payment_id = Column(String(100), nullable=True)

    # Timestamps
    is_visible        = Column(Boolean, default=True)   # soft delete
    created_at        = Column(DateTime, default=datetime.utcnow)
    ready_at          = Column(DateTime, nullable=True)
    delivered_at      = Column(DateTime, nullable=True)
    expires_at        = Column(DateTime, nullable=True)  # auto-delete after 7 days

    # Delivery tracking
    delivery_started_at  = Column(DateTime, nullable=True)
    delivery_completed_at = Column(DateTime, nullable=True)

    user             = relationship("User", back_populates="orders")
    zone             = relationship("Zone", back_populates="orders")
    hub              = relationship("Hub", back_populates="orders")
    agent            = relationship("Agent", back_populates="orders")
    delivery_partner = relationship("DeliveryPartner", back_populates="deliveries")
    files            = relationship("OrderFile", back_populates="order")
    payments         = relationship("Payment", back_populates="order")


# ── ORDER FILE ────────────────────────────────────────────────────────────

class OrderFile(Base):
    __tablename__ = "order_files"

    id           = Column(Integer, primary_key=True, index=True)
    order_id     = Column(Integer, ForeignKey("print_orders.id"), nullable=True)
    user_id      = Column(Integer, ForeignKey("users.id"), nullable=False)
    original_name = Column(String(255), nullable=False)
    saved_name   = Column(String(255), nullable=False)   # UUID filename
    file_path    = Column(String(500), nullable=False)
    file_size    = Column(Integer, default=0)
    page_count   = Column(Integer, default=1)
    color_type   = Column(String(10), default="bw")      # bw | color
    sided        = Column(String(10), default="single")  # single | double
    copies       = Column(Integer, default=1)
    binding      = Column(Boolean, default=False)
    color_sheet  = Column(Boolean, default=False)
    custom_note  = Column(Text, nullable=True)
    file_price   = Column(Float, default=0.0)
    is_encrypted = Column(Boolean, default=False)
    created_at   = Column(DateTime, default=datetime.utcnow)
    expires_at   = Column(DateTime, nullable=True)

    order = relationship("PrintOrder", back_populates="files")
    user  = relationship("User", back_populates="files")


# ── PAYMENT ───────────────────────────────────────────────────────────────

class Payment(Base):
    __tablename__ = "payments"

    id                  = Column(Integer, primary_key=True, index=True)
    order_id            = Column(Integer, ForeignKey("print_orders.id"), nullable=False)
    razorpay_order_id   = Column(String(100), nullable=True)
    razorpay_payment_id = Column(String(100), nullable=True)
    razorpay_signature  = Column(String(255), nullable=True)
    amount              = Column(Float, nullable=False)
    currency            = Column(String(5), default="INR")
    status              = Column(SAEnum(PaymentStatus), default=PaymentStatus.pending)
    method              = Column(String(20), nullable=True)   # upi | card | cash
    created_at          = Column(DateTime, default=datetime.utcnow)

    order = relationship("PrintOrder", back_populates="payments")


# ── FEATURE ───────────────────────────────────────────────────────────────

class Feature(Base):
    __tablename__ = "features"

    id           = Column(Integer, primary_key=True, index=True)
    feature_name = Column(String(50), unique=True, nullable=False)
    enabled      = Column(Boolean, default=True)
    description  = Column(String(255), nullable=True)
    updated_at   = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
