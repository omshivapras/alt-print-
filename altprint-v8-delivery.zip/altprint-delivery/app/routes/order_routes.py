from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timedelta
import math, random, string

from app.database import get_db
from app.middleware.auth import get_current_user
from app.models import User, PrintOrder, OrderFile, Zone, ZoneStatus, OrderStatus

router = APIRouter(prefix="/app", tags=["App — Orders"])


def haversine(lat1, lng1, lat2, lng2):
    R = 6371
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlng/2)**2
    return R * 2 * math.asin(math.sqrt(a))

def find_zone(user_lat, user_lng, db):
    zones = db.query(Zone).filter(Zone.status == ZoneStatus.active, Zone.is_accepting_orders == True).all()
    if not zones:
        return None
    inside = [z for z in zones if haversine(user_lat, user_lng, z.center_lat, z.center_lng) <= z.radius_km]
    if inside:
        return inside[0]
    return min(zones, key=lambda z: haversine(user_lat, user_lng, z.center_lat, z.center_lng))

def gen_order_ref():
    return "XR-" + "".join(random.choices(string.digits, k=8))

def calc_price(files_data):
    rates = {"bw_single": 2, "bw_double": 3, "color_single": 10, "color_double": 18,
             "binding": 30, "color_sheet": 15}
    total = 0
    for f in files_data:
        pages = f.get("page_count", 1)
        copies = f.get("copies", 1)
        sides = f.get("sided", "single")
        ctype = f.get("color_type", "bw")
        sheets = math.ceil(pages / 2) if sides == "double" else pages
        rate = rates.get(f"{ctype}_{sides}", 2)
        price = sheets * rate * copies
        if f.get("binding"): price += rates["binding"]
        if f.get("color_sheet"): price += rates["color_sheet"]
        total += price
    return total


class FileSpec(BaseModel):
    file_id: int
    color_type: str = "bw"
    sided: str = "single"
    copies: int = 1
    binding: bool = False
    color_sheet: bool = False
    custom_note: Optional[str] = None

class CreateOrderRequest(BaseModel):
    files: List[FileSpec]
    delivery_mode: str = "pickup"
    delivery_address: Optional[str] = None
    delivery_lat: Optional[float] = None
    delivery_lng: Optional[float] = None
    user_lat: Optional[float] = None
    user_lng: Optional[float] = None


@router.post("/create-order", status_code=201)
def create_order(req: CreateOrderRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # Zone assignment
    zone_id = None
    if req.user_lat and req.user_lng:
        zone = find_zone(req.user_lat, req.user_lng, db)
        if not zone:
            raise HTTPException(503, "No active zone available in your area. Service not available.")
        zone_id = zone.id
    elif user.zone_id:
        zone_id = user.zone_id

    # Get file records
    file_records = []
    for spec in req.files:
        f = db.query(OrderFile).filter(OrderFile.id == spec.file_id, OrderFile.user_id == user.id).first()
        if not f:
            raise HTTPException(404, f"File {spec.file_id} not found")
        f.color_type = spec.color_type
        f.sided = spec.sided
        f.copies = spec.copies
        f.binding = spec.binding
        f.color_sheet = spec.color_sheet
        f.custom_note = spec.custom_note
        file_records.append(f)

    # Delivery charge
    delivery_cost = 0
    if req.delivery_mode == "delivery":
        delivery_cost = 30

    # Calculate price
    files_data = [{"page_count": f.page_count, "color_type": f.color_type,
                   "sided": f.sided, "copies": f.copies, "binding": f.binding,
                   "color_sheet": f.color_sheet} for f in file_records]
    subtotal = calc_price(files_data)
    total = subtotal + delivery_cost

    # Create order
    order = PrintOrder(
        order_ref=gen_order_ref(),
        user_id=user.id,
        zone_id=zone_id,
        total_price=total,
        delivery_mode=req.delivery_mode,
        delivery_address=req.delivery_address,
        delivery_lat=req.delivery_lat,
        delivery_lng=req.delivery_lng,
        delivery_cost=delivery_cost,
        user_lat=req.user_lat,
        user_lng=req.user_lng,
        expires_at=datetime.utcnow() + timedelta(days=7),
    )
    db.add(order); db.commit(); db.refresh(order)

    for f in file_records:
        f.order_id = order.id
    db.commit()

    return {
        "success": True,
        "order_ref": order.order_ref,
        "order_id": order.id,
        "total_price": total,
        "delivery_cost": delivery_cost,
        "zone_id": zone_id,
        "status": order.status,
    }


@router.get("/orders")
def get_my_orders(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    orders = db.query(PrintOrder).filter(
        PrintOrder.user_id == user.id, PrintOrder.is_visible == True
    ).order_by(PrintOrder.created_at.desc()).all()

    result = []
    for o in orders:
        partner_info = None
        if o.delivery_partner and o.status == OrderStatus.out_for_delivery:
            partner_info = {
                "name": o.delivery_partner.name,
                "phone": o.delivery_partner.phone,
                "vehicle_type": o.delivery_partner.vehicle_type,
                "current_lat": o.delivery_partner.current_lat,
                "current_lng": o.delivery_partner.current_lng,
            }
        result.append({
            "order_id": o.id,
            "order_ref": o.order_ref,
            "status": o.status,
            "payment_status": o.payment_status,
            "total_price": o.total_price,
            "delivery_mode": o.delivery_mode,
            "file_count": len(o.files),
            "delivery_partner": partner_info,
            "created_at": o.created_at.isoformat(),
        })
    return {"success": True, "count": len(result), "orders": result}


@router.put("/hide-order/{order_id}")
def hide_order(order_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    order = db.query(PrintOrder).filter(PrintOrder.id == order_id, PrintOrder.user_id == user.id).first()
    if not order:
        raise HTTPException(404, "Order not found")
    order.is_visible = False
    db.commit()
    return {"success": True, "message": "Order hidden from history"}
