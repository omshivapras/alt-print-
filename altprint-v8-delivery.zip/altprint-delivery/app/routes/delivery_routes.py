"""
Delivery Partner Routes
POST /delivery/login              — partner logs in
GET  /delivery/my-orders          — see assigned orders
POST /delivery/update-location    — update live GPS
POST /delivery/start-delivery/{order_id}   — start delivery → user sees partner info
POST /delivery/complete/{order_id}         — mark delivered
GET  /delivery/profile            — partner own profile

Admin routes (prefix /admin):
POST /admin/create-delivery-partner
GET  /admin/delivery-partners
PATCH /admin/delivery-partner/{id}/assign-zone
PATCH /admin/order/{id}/assign-delivery-partner
GET  /admin/delivery-partner/{id}/location
"""
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import uuid, os, bcrypt, json
from jose import jwt, JWTError

from app.database import get_db
from app.models import DeliveryPartner, PrintOrder, OrderStatus, DeliveryStatus, User
from app.middleware.auth import get_current_user, SECRET_KEY, ALGORITHM

router_delivery = APIRouter(prefix="/delivery", tags=["Delivery Partner"])
router_admin_delivery = APIRouter(prefix="/admin", tags=["Admin — Delivery"])


# ── SCHEMAS ───────────────────────────────────────────────────────────────

class DeliveryLoginRequest(BaseModel):
    phone: str
    password: str

class LocationUpdate(BaseModel):
    lat: float
    lng: float

class CreateDeliveryPartnerRequest(BaseModel):
    name: str
    phone: str
    email: Optional[str] = None
    password: str
    vehicle_type: Optional[str] = "bike"
    vehicle_number: Optional[str] = None
    zone_id: Optional[int] = None
    hub_id: Optional[int] = None


# ── HELPERS ───────────────────────────────────────────────────────────────

def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

def verify_password(pw: str, hashed: str) -> bool:
    return bcrypt.checkpw(pw.encode(), hashed.encode())

def create_delivery_token(partner_id: int, phone: str) -> str:
    return jwt.encode(
        {"sub": str(partner_id), "phone": phone, "type": "delivery"},
        SECRET_KEY, algorithm=ALGORITHM
    )

def get_current_delivery_partner(token: str, db: Session) -> DeliveryPartner:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("type") != "delivery":
            raise HTTPException(status_code=401, detail="Not a delivery partner token")
        partner_id = int(payload["sub"])
        partner = db.query(DeliveryPartner).filter(DeliveryPartner.id == partner_id).first()
        if not partner or not partner.is_active:
            raise HTTPException(status_code=401, detail="Partner not found or inactive")
        return partner
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

def partner_token_dep(
    authorization: str = None,
    db: Session = Depends(get_db)
) -> DeliveryPartner:
    from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
    raise HTTPException(status_code=401, detail="Use Authorization: Bearer <token>")


# Use this properly with HTTPBearer
from fastapi import Header

def get_partner_from_token(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authentication required. Send Authorization: Bearer <token>")
    token = authorization.split(" ", 1)[1]
    return get_current_delivery_partner(token, db)


# ── DELIVERY PARTNER LOGIN ────────────────────────────────────────────────

@router_delivery.post("/login")
def delivery_partner_login(req: DeliveryLoginRequest, db: Session = Depends(get_db)):
    """Delivery partner login — separate from user login"""
    partner = db.query(DeliveryPartner).filter(
        DeliveryPartner.phone == req.phone,
        DeliveryPartner.is_active == True
    ).first()

    if not partner or not verify_password(req.password, partner.password):
        raise HTTPException(status_code=401, detail="Invalid phone or password")

    partner.is_online = True
    db.commit()

    token = create_delivery_token(partner.id, partner.phone)

    return {
        "success": True,
        "access_token": token,
        "token_type": "bearer",
        "partner": {
            "partner_id": partner.id,
            "name": partner.name,
            "phone": partner.phone,
            "vehicle_type": partner.vehicle_type,
            "vehicle_number": partner.vehicle_number,
            "zone_id": partner.zone_id,
            "hub_id": partner.hub_id,
            "is_online": partner.is_online,
            "delivery_status": partner.delivery_status,
        }
    }


# ── GET PARTNER PROFILE ───────────────────────────────────────────────────

@router_delivery.get("/profile")
def get_my_profile(partner: DeliveryPartner = Depends(get_partner_from_token)):
    """Get delivery partner own profile"""
    return {
        "success": True,
        "partner": {
            "partner_id": partner.id,
            "name": partner.name,
            "phone": partner.phone,
            "email": partner.email,
            "vehicle_type": partner.vehicle_type,
            "vehicle_number": partner.vehicle_number,
            "zone_id": partner.zone_id,
            "hub_id": partner.hub_id,
            "is_online": partner.is_online,
            "is_on_delivery": partner.is_on_delivery,
            "delivery_status": partner.delivery_status,
            "current_lat": partner.current_lat,
            "current_lng": partner.current_lng,
        }
    }


# ── SEE MY ASSIGNED ORDERS ────────────────────────────────────────────────

@router_delivery.get("/my-orders")
def get_my_orders(
    partner: DeliveryPartner = Depends(get_partner_from_token),
    db: Session = Depends(get_db)
):
    """
    Delivery partner sees orders assigned to them.
    Shows user phone, name, delivery address, and navigation coordinates.
    """
    orders = db.query(PrintOrder).filter(
        PrintOrder.delivery_partner_id == partner.id,
        PrintOrder.delivery_mode == "delivery",
        PrintOrder.status.in_([
            OrderStatus.ready,
            OrderStatus.out_for_delivery,
        ])
    ).all()

    result = []
    for o in orders:
        result.append({
            "order_id": o.id,
            "order_ref": o.order_ref,
            "status": o.status,
            "payment_status": o.payment_status,
            "total_price": o.total_price,
            # Customer details shown to partner
            "customer": {
                "name": o.user.name,
                "phone": o.user.phone,   # ← partner sees customer phone
            },
            # Navigation destination
            "delivery": {
                "address": o.delivery_address,
                "lat": o.delivery_lat,
                "lng": o.delivery_lng,
            },
            "created_at": o.created_at.isoformat(),
        })

    return {"success": True, "count": len(result), "orders": result}


# ── UPDATE LIVE LOCATION ──────────────────────────────────────────────────

@router_delivery.post("/update-location")
def update_location(
    loc: LocationUpdate,
    partner: DeliveryPartner = Depends(get_partner_from_token),
    db: Session = Depends(get_db)
):
    """
    Partner sends GPS coordinates — stored in DB.
    User can query this to get live navigation.
    Call this every 10-15 seconds while on delivery.
    """
    partner.current_lat = loc.lat
    partner.current_lng = loc.lng
    partner.last_location_update = datetime.utcnow()
    db.commit()

    return {
        "success": True,
        "message": "Location updated",
        "lat": loc.lat,
        "lng": loc.lng,
        "updated_at": partner.last_location_update.isoformat()
    }


# ── START DELIVERY ────────────────────────────────────────────────────────

@router_delivery.post("/start-delivery/{order_id}")
def start_delivery(
    order_id: int,
    partner: DeliveryPartner = Depends(get_partner_from_token),
    db: Session = Depends(get_db)
):
    """
    Partner picks up order from hub and starts delivery.
    Order status → out_for_delivery
    User can now see partner's live location + phone number.
    """
    order = db.query(PrintOrder).filter(
        PrintOrder.id == order_id,
        PrintOrder.delivery_partner_id == partner.id
    ).first()

    if not order:
        raise HTTPException(status_code=404, detail="Order not found or not assigned to you")

    if order.status != OrderStatus.ready:
        raise HTTPException(status_code=400, detail=f"Order is {order.status}, must be 'ready' to start delivery")

    order.status = OrderStatus.out_for_delivery
    order.delivery_started_at = datetime.utcnow()
    partner.is_on_delivery = True
    partner.delivery_status = DeliveryStatus.on_route
    db.commit()

    return {
        "success": True,
        "message": "Delivery started! User can now track your location.",
        "order_ref": order.order_ref,
        "delivery_address": order.delivery_address,
        "customer": {
            "name": order.user.name,
            "phone": order.user.phone,
        },
        "navigation": {
            "destination_lat": order.delivery_lat,
            "destination_lng": order.delivery_lng,
        }
    }


# ── COMPLETE DELIVERY ─────────────────────────────────────────────────────

@router_delivery.post("/complete/{order_id}")
def complete_delivery(
    order_id: int,
    partner: DeliveryPartner = Depends(get_partner_from_token),
    db: Session = Depends(get_db)
):
    """Mark delivery as completed"""
    order = db.query(PrintOrder).filter(
        PrintOrder.id == order_id,
        PrintOrder.delivery_partner_id == partner.id,
        PrintOrder.status == OrderStatus.out_for_delivery
    ).first()

    if not order:
        raise HTTPException(status_code=404, detail="Order not found or not in transit")

    order.status = OrderStatus.delivered
    order.delivery_completed_at = datetime.utcnow()
    order.delivered_at = datetime.utcnow()
    partner.is_on_delivery = False
    partner.delivery_status = DeliveryStatus.idle
    db.commit()

    return {
        "success": True,
        "message": "Delivery completed!",
        "order_ref": order.order_ref,
        "completed_at": order.delivery_completed_at.isoformat()
    }


# ── GO OFFLINE ────────────────────────────────────────────────────────────

@router_delivery.post("/go-offline")
def go_offline(
    partner: DeliveryPartner = Depends(get_partner_from_token),
    db: Session = Depends(get_db)
):
    """Partner goes offline"""
    partner.is_online = False
    partner.delivery_status = DeliveryStatus.idle
    db.commit()
    return {"success": True, "message": "You are now offline"}


# ── USER TRACKING ENDPOINT ────────────────────────────────────────────────
# This is called from /app prefix — added here for clarity

def get_delivery_tracking(order_id: int, user: User, db: Session):
    """
    User calls this to get live delivery partner location.
    Returns partner name, phone, and current GPS.
    """
    order = db.query(PrintOrder).filter(
        PrintOrder.id == order_id,
        PrintOrder.user_id == user.id
    ).first()

    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    if order.delivery_mode != "delivery":
        raise HTTPException(status_code=400, detail="This is a pickup order")

    if order.status not in [OrderStatus.out_for_delivery, OrderStatus.ready]:
        return {
            "success": True,
            "status": order.status,
            "message": "Delivery not started yet" if order.status != OrderStatus.delivered else "Order delivered!",
            "partner": None
        }

    partner = order.delivery_partner
    if not partner:
        return {
            "success": True,
            "status": order.status,
            "message": "Delivery partner not assigned yet",
            "partner": None
        }

    return {
        "success": True,
        "status": order.status,
        "order_ref": order.order_ref,
        "partner": {
            "name": partner.name,
            "phone": partner.phone,       # ← user sees partner phone
            "vehicle_type": partner.vehicle_type,
            "vehicle_number": partner.vehicle_number,
            # Live GPS — updated by partner every ~10 sec
            "current_lat": partner.current_lat,
            "current_lng": partner.current_lng,
            "last_updated": partner.last_location_update.isoformat() if partner.last_location_update else None,
        },
        "delivery": {
            "address": order.delivery_address,
            "started_at": order.delivery_started_at.isoformat() if order.delivery_started_at else None,
        }
    }


# ── ADMIN: CREATE DELIVERY PARTNER ───────────────────────────────────────

@router_admin_delivery.post("/create-delivery-partner")
def create_delivery_partner(
    req: CreateDeliveryPartnerRequest,
    db: Session = Depends(get_db)
):
    """Admin creates a delivery partner account"""
    existing = db.query(DeliveryPartner).filter(
        DeliveryPartner.phone == req.phone
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Phone already registered")

    partner = DeliveryPartner(
        name=req.name,
        phone=req.phone,
        email=req.email,
        password=hash_password(req.password),
        vehicle_type=req.vehicle_type,
        vehicle_number=req.vehicle_number,
        zone_id=req.zone_id,
        hub_id=req.hub_id,
    )
    db.add(partner)
    db.commit()
    db.refresh(partner)

    return {
        "success": True,
        "message": f"Delivery partner '{req.name}' created",
        "partner_id": partner.id,
        "phone": partner.phone,
    }


# ── ADMIN: LIST ALL DELIVERY PARTNERS ─────────────────────────────────────

@router_admin_delivery.get("/delivery-partners")
def list_delivery_partners(db: Session = Depends(get_db)):
    """Admin views all delivery partners with status"""
    partners = db.query(DeliveryPartner).all()
    result = []
    for p in partners:
        result.append({
            "partner_id": p.id,
            "name": p.name,
            "phone": p.phone,
            "email": p.email,
            "vehicle_type": p.vehicle_type,
            "vehicle_number": p.vehicle_number,
            "zone_id": p.zone_id,
            "hub_id": p.hub_id,
            "is_active": p.is_active,
            "is_online": p.is_online,
            "is_on_delivery": p.is_on_delivery,
            "delivery_status": p.delivery_status,
            "current_lat": p.current_lat,
            "current_lng": p.current_lng,
            "last_location_update": p.last_location_update.isoformat() if p.last_location_update else None,
        })
    return {"success": True, "count": len(result), "partners": result}


# ── ADMIN: GET LIVE LOCATION OF PARTNER ───────────────────────────────────

@router_admin_delivery.get("/delivery-partner/{partner_id}/location")
def get_partner_location(partner_id: int, db: Session = Depends(get_db)):
    """Admin sees live location of a delivery partner"""
    partner = db.query(DeliveryPartner).filter(DeliveryPartner.id == partner_id).first()
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")

    return {
        "success": True,
        "partner_id": partner.id,
        "name": partner.name,
        "phone": partner.phone,
        "is_online": partner.is_online,
        "is_on_delivery": partner.is_on_delivery,
        "delivery_status": partner.delivery_status,
        "location": {
            "lat": partner.current_lat,
            "lng": partner.current_lng,
            "last_updated": partner.last_location_update.isoformat() if partner.last_location_update else None,
        }
    }


# ── ADMIN: ASSIGN PARTNER TO ORDER ───────────────────────────────────────

@router_admin_delivery.patch("/order/{order_id}/assign-delivery-partner")
def assign_delivery_partner(
    order_id: int,
    partner_id: int,
    db: Session = Depends(get_db)
):
    """Admin assigns a delivery partner to an order"""
    order = db.query(PrintOrder).filter(PrintOrder.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    partner = db.query(DeliveryPartner).filter(
        DeliveryPartner.id == partner_id,
        DeliveryPartner.is_active == True
    ).first()
    if not partner:
        raise HTTPException(status_code=404, detail="Delivery partner not found or inactive")

    order.delivery_partner_id = partner_id
    partner.delivery_status = DeliveryStatus.assigned
    db.commit()

    return {
        "success": True,
        "message": f"Partner '{partner.name}' assigned to order {order.order_ref}",
        "partner_phone": partner.phone,
    }


# ── ADMIN: ASSIGN PARTNER TO ZONE ─────────────────────────────────────────

@router_admin_delivery.patch("/delivery-partner/{partner_id}/assign-zone")
def assign_partner_to_zone(
    partner_id: int,
    zone_id: int,
    hub_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """Admin assigns delivery partner to a zone/hub"""
    partner = db.query(DeliveryPartner).filter(DeliveryPartner.id == partner_id).first()
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")

    partner.zone_id = zone_id
    if hub_id:
        partner.hub_id = hub_id
    db.commit()

    return {
        "success": True,
        "message": f"Partner assigned to zone {zone_id}",
        "partner_id": partner_id,
        "zone_id": zone_id,
        "hub_id": hub_id,
    }


# ── ADMIN: TOGGLE PARTNER ACTIVE STATUS ───────────────────────────────────

@router_admin_delivery.patch("/delivery-partner/{partner_id}/toggle-active")
def toggle_partner_active(partner_id: int, db: Session = Depends(get_db)):
    """Admin activates or deactivates a delivery partner"""
    partner = db.query(DeliveryPartner).filter(DeliveryPartner.id == partner_id).first()
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")

    partner.is_active = not partner.is_active
    db.commit()

    return {
        "success": True,
        "partner_id": partner_id,
        "is_active": partner.is_active,
        "message": f"Partner {'activated' if partner.is_active else 'deactivated'}"
    }
