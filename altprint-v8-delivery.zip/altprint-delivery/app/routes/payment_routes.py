from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from pydantic import BaseModel
from app.database import get_db
from app.middleware.auth import get_current_user
from app.models import User, PrintOrder, Payment, PaymentStatus
import os, hashlib, hmac

router = APIRouter(prefix="/app", tags=["App — Payments"])

RAZORPAY_KEY_ID     = os.getenv("RAZORPAY_KEY_ID", "")
RAZORPAY_KEY_SECRET = os.getenv("RAZORPAY_KEY_SECRET", "")


class VerifyPaymentRequest(BaseModel):
    order_id: int
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str


@router.post("/payment/create-order")
def create_payment_order(order_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Create Razorpay payment order. Frontend uses returned id to open payment popup."""
    order = db.query(PrintOrder).filter(PrintOrder.id == order_id, PrintOrder.user_id == user.id).first()
    if not order:
        raise HTTPException(404, "Order not found")
    if order.payment_status == PaymentStatus.paid:
        raise HTTPException(400, "Order already paid")

    if not RAZORPAY_KEY_ID:
        # Demo mode
        return {
            "success": True,
            "razorpay_key_id": "rzp_test_demo",
            "razorpay_order_id": f"order_demo_{order.id}",
            "amount": int(order.total_price * 100),
            "currency": "INR",
            "note": "Add RAZORPAY_KEY_ID to .env for live payments"
        }

    try:
        import razorpay
        client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))
        rzp_order = client.order.create({
            "amount": int(order.total_price * 100),
            "currency": "INR",
            "receipt": order.order_ref,
        })
        order.razorpay_order_id = rzp_order["id"]
        db.commit()
        return {
            "success": True,
            "razorpay_key_id": RAZORPAY_KEY_ID,
            "razorpay_order_id": rzp_order["id"],
            "amount": int(order.total_price * 100),
            "currency": "INR",
            "order_ref": order.order_ref,
        }
    except Exception as e:
        raise HTTPException(500, f"Payment gateway error: {str(e)}")


@router.post("/payment/verify")
def verify_payment(req: VerifyPaymentRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Verify Razorpay payment signature after user pays."""
    order = db.query(PrintOrder).filter(PrintOrder.id == req.order_id, PrintOrder.user_id == user.id).first()
    if not order:
        raise HTTPException(404, "Order not found")

    # Verify signature
    if RAZORPAY_KEY_SECRET:
        body = f"{req.razorpay_order_id}|{req.razorpay_payment_id}"
        expected = hmac.new(RAZORPAY_KEY_SECRET.encode(), body.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, req.razorpay_signature):
            raise HTTPException(400, "Payment verification failed — invalid signature")

    order.payment_status = PaymentStatus.paid
    order.razorpay_payment_id = req.razorpay_payment_id
    order.razorpay_order_id = req.razorpay_order_id
    db.commit()

    pay = Payment(
        order_id=order.id,
        razorpay_order_id=req.razorpay_order_id,
        razorpay_payment_id=req.razorpay_payment_id,
        razorpay_signature=req.razorpay_signature,
        amount=order.total_price,
        status=PaymentStatus.paid,
        method="upi",
    )
    db.add(pay); db.commit()

    return {"success": True, "message": "Payment verified! Order confirmed.", "order_ref": order.order_ref}


@router.put("/mark-paid/{order_id}")
def mark_paid_cash(order_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """User marks order as paid (cash on pickup)."""
    order = db.query(PrintOrder).filter(PrintOrder.id == order_id, PrintOrder.user_id == user.id).first()
    if not order:
        raise HTTPException(404, "Order not found")
    order.payment_status = PaymentStatus.paid
    db.commit()
    return {"success": True, "message": "Marked as paid (cash)"}
