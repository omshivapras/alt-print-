from fastapi import APIRouter, Depends, HTTPException, UploadFile, File as FastFile
from fastapi.responses import Response
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import uuid, os, shutil

from app.database import get_db
from app.middleware.auth import get_current_user
from app.models import User, OrderFile

router = APIRouter(prefix="/app", tags=["App — Files"])
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED = {"pdf", "jpg", "jpeg", "png", "docx"}
MAX_MB = 50


def count_pages(path: str, ext: str) -> int:
    try:
        if ext == "pdf":
            import pdfplumber
            with pdfplumber.open(path) as p:
                return len(p.pages)
        return 1
    except:
        return 1


@router.post("/upload-file")
def upload_file(
    file: UploadFile = FastFile(...),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    ext = (file.filename or "").rsplit(".", 1)[-1].lower()
    if ext not in ALLOWED:
        raise HTTPException(400, f"File type .{ext} not allowed. Allowed: {', '.join(ALLOWED)}")

    content = file.file.read()
    if len(content) > MAX_MB * 1024 * 1024:
        raise HTTPException(400, f"File too large. Max {MAX_MB} MB")

    saved_name = f"{uuid.uuid4()}.{ext}"
    path = os.path.join(UPLOAD_DIR, saved_name)
    with open(path, "wb") as f:
        f.write(content)

    pages = count_pages(path, ext)

    rec = OrderFile(
        user_id=user.id,
        original_name=file.filename,
        saved_name=saved_name,
        file_path=path,
        file_size=len(content),
        page_count=pages,
        expires_at=datetime.utcnow() + timedelta(days=7),
    )
    db.add(rec); db.commit(); db.refresh(rec)

    return {
        "success": True,
        "file_id": rec.id,
        "original_name": file.filename,
        "page_count": pages,
        "file_size_kb": round(len(content) / 1024, 1),
        "expires_at": rec.expires_at.isoformat(),
    }


@router.get("/file/{file_id}/download")
def download_file(file_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rec = db.query(OrderFile).filter(OrderFile.id == file_id, OrderFile.user_id == user.id).first()
    if not rec:
        raise HTTPException(404, "File not found")
    if not os.path.exists(rec.file_path):
        raise HTTPException(404, "File no longer exists (may have been auto-deleted)")

    with open(rec.file_path, "rb") as f:
        content = f.read()
    return Response(content=content, media_type="application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{rec.original_name}"'})
