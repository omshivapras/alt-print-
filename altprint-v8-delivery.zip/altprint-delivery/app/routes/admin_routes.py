from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from app.database import get_db
from app.models import Zone, ZoneStatus, Hub, PrintOrder, User, Feature, UserRole, OrderStatus
from datetime import datetime

router = APIRouter(prefix="/admin", tags=["Admin"])


class ZoneCreate(BaseModel):
    name: str
    center_lat: float
    center_lng: float
    radius_km: float = 5.0

class HubCreate(BaseModel):
    name: str
    zone_id: int
    address: Optional[str] = None
    lat: Optional[float] = None
    lng: Optional[float] = None


@router.post("/create-zone")
def create_zone(req: ZoneCreate, db: Session = Depends(get_db)):
    z = Zone(**req.model_dump())
    db.add(z); db.commit(); db.refresh(z)
    return {"success": True, "zone_id": z.id, "name": z.name}

@router.get("/zones")
def list_zones(db: Session = Depends(get_db)):
    zones = db.query(Zone).all()
    return {"success": True, "zones": [
        {"zone_id": z.id, "name": z.name, "status": z.status,
         "is_accepting_orders": z.is_accepting_orders, "radius_km": z.radius_km}
        for z in zones
    ]}

@router.patch("/zone/{zone_id}/activate")
def activate_zone(zone_id: int, db: Session = Depends(get_db)):
    z = db.query(Zone).filter(Zone.id == zone_id).first()
    if not z: raise HTTPException(404, "Zone not found")
    z.status = ZoneStatus.active; db.commit()
    return {"success": True, "zone_id": zone_id, "status": "active"}

@router.patch("/zone/{zone_id}/deactivate")
def deactivate_zone(zone_id: int, db: Session = Depends(get_db)):
    z = db.query(Zone).filter(Zone.id == zone_id).first()
    if not z: raise HTTPException(404, "Zone not found")
    z.status = ZoneStatus.inactive; db.commit()
    return {"success": True, "zone_id": zone_id, "status": "inactive"}

@router.post("/create-hub")
def create_hub(req: HubCreate, db: Session = Depends(get_db)):
    h = Hub(**req.model_dump())
    db.add(h); db.commit(); db.refresh(h)
    return {"success": True, "hub_id": h.id, "name": h.name}

@router.get("/hubs")
def list_hubs(db: Session = Depends(get_db)):
    hubs = db.query(Hub).all()
    return {"success": True, "hubs": [
        {"hub_id": h.id, "name": h.name, "zone_id": h.zone_id, "address": h.address}
        for h in hubs
    ]}

@router.get("/orders")
def all_orders(db: Session = Depends(get_db)):
    orders = db.query(PrintOrder).order_by(PrintOrder.created_at.desc()).limit(100).all()
    return {"success": True, "count": len(orders), "orders": [
        {"order_id": o.id, "order_ref": o.order_ref, "user_id": o.user_id,
         "status": o.status, "payment_status": o.payment_status,
         "total_price": o.total_price, "zone_id": o.zone_id,
         "delivery_mode": o.delivery_mode, "delivery_partner_id": o.delivery_partner_id,
         "created_at": o.created_at.isoformat()}
        for o in orders
    ]}

@router.patch("/order/{order_id}/status")
def update_order_status(order_id: int, new_status: str, db: Session = Depends(get_db)):
    order = db.query(PrintOrder).filter(PrintOrder.id == order_id).first()
    if not order: raise HTTPException(404, "Order not found")
    try:
        order.status = OrderStatus(new_status)
        if new_status == "ready": order.ready_at = datetime.utcnow()
        db.commit()
    except ValueError:
        raise HTTPException(400, f"Invalid status. Valid: {[s.value for s in OrderStatus]}")
    return {"success": True, "order_id": order_id, "new_status": new_status}

@router.get("/users")
def list_users(db: Session = Depends(get_db)):
    users = db.query(User).all()
    return {"success": True, "users": [
        {"user_id": u.id, "name": u.name, "email": u.email,
         "phone": u.phone, "role": u.role, "zone_id": u.zone_id}
        for u in users
    ]}

@router.patch("/user/{user_id}/role")
def set_user_role(user_id: int, role: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user: raise HTTPException(404, "User not found")
    try:
        user.role = UserRole(role)
        db.commit()
    except ValueError:
        raise HTTPException(400, f"Invalid role. Valid: {[r.value for r in UserRole]}")
    return {"success": True, "user_id": user_id, "new_role": role}

@router.get("/features")
def list_features(db: Session = Depends(get_db)):
    features = db.query(Feature).all()
    return {"success": True, "features": [
        {"feature_name": f.feature_name, "enabled": f.enabled, "description": f.description}
        for f in features
    ]}

@router.patch("/feature/{feature_name}")
def toggle_feature(feature_name: str, enabled: bool, db: Session = Depends(get_db)):
    f = db.query(Feature).filter(Feature.feature_name == feature_name).first()
    if not f: raise HTTPException(404, "Feature not found")
    f.enabled = enabled; db.commit()
    return {"success": True, "feature_name": feature_name, "enabled": enabled}
