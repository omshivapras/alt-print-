from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, field_validator
from typing import Optional
import bcrypt, json

from app.database import get_db
from app.models import User, UserRole
from app.middleware.auth import create_access_token, get_current_user

router = APIRouter(prefix="/app", tags=["Auth"])


class RegisterRequest(BaseModel):
    name: str
    email: str
    phone: str
    password: str

    @field_validator("phone")
    @classmethod
    def validate_phone(cls, v):
        v = v.strip().replace(" ", "")
        if not (v.isdigit() and len(v) == 10 and v[0] in "6789"):
            raise ValueError("Invalid phone. Must be 10-digit Indian mobile (starts with 6-9)")
        return v

    @field_validator("name")
    @classmethod
    def validate_name(cls, v):
        if len(v.strip()) < 2:
            raise ValueError("Name must be at least 2 characters")
        return v.strip()

    @field_validator("password")
    @classmethod
    def validate_password(cls, v):
        if len(v) < 6:
            raise ValueError("Password must be at least 6 characters")
        return v


class LoginRequest(BaseModel):
    email: str
    password: str


def hash_pw(pw): return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()
def verify_pw(pw, h): return bcrypt.checkpw(pw.encode(), h.encode())


@router.post("/register", status_code=201)
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == req.email).first():
        raise HTTPException(400, "Email already registered")
    if db.query(User).filter(User.phone == req.phone).first():
        raise HTTPException(400, "Phone already registered")

    user = User(
        name=req.name, email=req.email,
        phone=req.phone, password=hash_pw(req.password),
        role=UserRole.user
    )
    db.add(user); db.commit(); db.refresh(user)
    token = create_access_token(user.id, user.role)
    return {
        "success": True, "access_token": token, "token_type": "bearer",
        "user": {"user_id": user.id, "name": user.name, "email": user.email,
                 "phone": user.phone, "role": user.role}
    }


@router.post("/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == req.email, User.is_active == True).first()
    if not user or not verify_pw(req.password, user.password):
        raise HTTPException(401, "Invalid email or password")
    token = create_access_token(user.id, user.role)
    return {
        "success": True, "access_token": token, "token_type": "bearer",
        "user": {"user_id": user.id, "name": user.name, "email": user.email,
                 "phone": user.phone, "role": user.role, "zone_id": user.zone_id}
    }


@router.get("/me")
def me(user: User = Depends(get_current_user)):
    perms = []
    try: perms = json.loads(user.permissions or "[]")
    except: pass
    return {
        "success": True,
        "user": {"user_id": user.id, "name": user.name, "email": user.email,
                 "phone": user.phone, "role": user.role, "zone_id": user.zone_id,
                 "permissions": perms}
    }
