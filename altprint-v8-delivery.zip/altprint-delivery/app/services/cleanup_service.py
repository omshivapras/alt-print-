from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
import os
from loguru import logger


def cleanup_expired():
    from app.database import SessionLocal
    from app.models import OrderFile, PrintOrder
    db = SessionLocal()
    try:
        now = datetime.utcnow()
        expired_files = db.query(OrderFile).filter(
            OrderFile.expires_at != None, OrderFile.expires_at < now
        ).all()
        deleted_files = 0
        for f in expired_files:
            if f.file_path and os.path.exists(f.file_path):
                os.remove(f.file_path)
                deleted_files += 1
            db.delete(f)
        db.commit()
        if deleted_files:
            logger.info(f"🗑️ Cleanup: deleted {deleted_files} expired files")
    except Exception as e:
        logger.error(f"Cleanup error: {e}")
    finally:
        db.close()


def start_scheduler():
    scheduler = BackgroundScheduler(timezone="Asia/Kolkata")
    scheduler.add_job(cleanup_expired, "cron", hour=2, minute=0)
    scheduler.start()
    logger.info("✅ Cleanup scheduler started — runs daily at 2:00 AM IST")
