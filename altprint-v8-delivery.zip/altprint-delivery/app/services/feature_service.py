from app.database import SessionLocal
from app.models import Feature
from loguru import logger


DEFAULTS = [
    ("black_xerox",  True,  "Black & White printing"),
    ("color_xerox",  True,  "Colour printing"),
    ("photo_print",  True,  "Photo printing"),
    ("tshirt_print", True,  "T-Shirt printing"),
    ("spiral_binding", True, "Spiral binding"),
    ("delivery",     True,  "Home delivery"),
]


def seed_features():
    db = SessionLocal()
    try:
        for name, enabled, desc in DEFAULTS:
            if not db.query(Feature).filter(Feature.feature_name == name).first():
                db.add(Feature(feature_name=name, enabled=enabled, description=desc))
        db.commit()
        logger.info("✅ Features seeded")
    finally:
        db.close()
