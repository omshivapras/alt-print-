# ALTPrint Mobile Backend v8.0

## Setup (Linux/Mac)
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp altprint.env .env
python3 main.py
# Open: http://localhost:8000/docs
```

## Setup (Windows)
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy altprint.env .env
python main.py
```

---

## URL Structure

| URL | Who | Control |
|-----|-----|---------|
| `/admin/...` | **Admin (Boss)** | Full control — zones, hubs, users, orders, features, delivery partners |
| `/app/...` | **Mobile Users** | Own orders, files, payments, delivery tracking |
| `/delivery/...` | **Delivery Partners** | Assigned orders, update live GPS location |

---

## Complete API Reference

### AUTH
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/app/register` | Register new user |
| POST | `/app/login` | Login → get JWT token |
| GET | `/app/me` | Your profile + role + permissions |

### USER — Files
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/app/upload-file` | Upload PDF/image |
| GET | `/app/file/{id}/download` | Download your file |

### USER — Orders
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/app/create-order` | Create print order |
| GET | `/app/orders` | My orders |
| PUT | `/app/hide-order/{id}` | Hide from history |
| GET | `/app/track-order/{id}` | **Live delivery tracking — partner name, phone, GPS** |

### USER — Payments
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/app/payment/create-order` | Create Razorpay payment |
| POST | `/app/payment/verify` | Verify payment signature |
| PUT | `/app/mark-paid/{id}` | Mark paid (cash) |

---

### DELIVERY PARTNER
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/delivery/login` | Delivery partner login (separate from user) |
| GET | `/delivery/profile` | My own profile |
| GET | `/delivery/my-orders` | My assigned orders (with customer phone + navigation) |
| POST | `/delivery/update-location` | **Update live GPS — call every 10-15 seconds** |
| POST | `/delivery/start-delivery/{id}` | Start delivery → user can now track |
| POST | `/delivery/complete/{id}` | Mark delivered |
| POST | `/delivery/go-offline` | Go offline |

---

### ADMIN
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/admin/create-zone` | Create service zone |
| GET | `/admin/zones` | List all zones |
| PATCH | `/admin/zone/{id}/activate` | Activate zone |
| PATCH | `/admin/zone/{id}/deactivate` | Deactivate zone |
| POST | `/admin/create-hub` | Create print hub |
| GET | `/admin/hubs` | List all hubs |
| GET | `/admin/orders` | All orders (boss view) |
| PATCH | `/admin/order/{id}/status` | Update order status |
| GET | `/admin/users` | All users |
| PATCH | `/admin/user/{id}/role` | Change user role |
| GET | `/admin/features` | List features |
| PATCH | `/admin/feature/{name}` | Enable/disable feature |

### ADMIN — Delivery Partners
| Method | URL | Description |
|--------|-----|-------------|
| POST | `/admin/create-delivery-partner` | Create partner account |
| GET | `/admin/delivery-partners` | All partners + live status |
| GET | `/admin/delivery-partner/{id}/location` | Live GPS of specific partner |
| PATCH | `/admin/order/{id}/assign-delivery-partner` | Assign partner to order |
| PATCH | `/admin/delivery-partner/{id}/assign-zone` | Assign partner to zone |
| PATCH | `/admin/delivery-partner/{id}/toggle-active` | Activate/deactivate partner |

---

## Delivery Flow

```
Admin creates delivery partner
           ↓
Order marked "ready" by shop
           ↓
Admin assigns delivery partner → PATCH /admin/order/{id}/assign-delivery-partner
           ↓
Partner logs in → POST /delivery/login
           ↓
Partner picks up order → POST /delivery/start-delivery/{id}
           ↓
Partner updates GPS every 10s → POST /delivery/update-location
           ↓
User polls → GET /app/track-order/{id}
           Returns: partner name, PHONE, live lat/lng
           Mobile app shows on Google Maps
           ↓
Partner delivers → POST /delivery/complete/{id}
           ↓
Order status → "delivered"
```

## What User Sees During Tracking

```json
{
  "status": "out_for_delivery",
  "partner": {
    "name": "Raju Kumar",
    "phone": "9876543210",
    "vehicle_type": "bike",
    "vehicle_number": "KA01AB1234",
    "current_lat": 12.9716,
    "current_lng": 77.5946,
    "last_updated": "2026-05-09T10:30:00"
  },
  "delivery": {
    "address": "123 Main St, Bengaluru",
    "started_at": "2026-05-09T10:00:00"
  }
}
```

## What Delivery Partner Sees

```json
{
  "order_ref": "XR-20240001",
  "customer": {
    "name": "Shiva Kumar",
    "phone": "9876543210"
  },
  "delivery": {
    "address": "123 Main St, Bengaluru",
    "lat": 12.9716,
    "lng": 77.5946
  }
}
```
