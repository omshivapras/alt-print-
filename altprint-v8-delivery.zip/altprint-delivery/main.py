"""
ALTPrint Mobile Backend v8.0
===========================
Mother URL : /admin  — full control (admin only)
User URL   : /app    — mobile users
Agent URL  : /agent  — shop staff
Delivery   : /delivery — delivery partners
"""
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.utils import get_openapi
from fastapi.security import HTTPBearer
from contextlib import asynccontextmanager
import logging, os

from app.database import engine, Base
from app.models import *   # noqa — registers all models
from app.services.feature_service import seed_features
from app.services.cleanup_service import start_scheduler

# ── ROUTE IMPORTS ─────────────────────────────────────────────────────────
from app.routes.auth_routes   import router as auth_router
from app.routes.admin_routes  import router as admin_router
from app.routes.order_routes  import router as order_router
from app.routes.file_routes   import router as file_router
from app.routes.payment_routes import router as payment_router
from app.routes.delivery_routes import router_delivery, router_admin_delivery

# ── LOGGING ───────────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/altprint.log"),
    ]
)
logger = logging.getLogger(__name__)

# ── LIFESPAN ──────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    Base.metadata.create_all(bind=engine)
    logger.info("✅ Database tables ready")
    seed_features()
    start_scheduler()
    logger.info("ALTPrint Mobile Backend v8.0 started")
    print("""
🖨️  ALTPrint Mobile Backend v8.0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 Swagger       → http://localhost:8000/docs
❤️  Health       → http://localhost:8000/health
🔑 User Login    → POST /app/login
🚚 Delivery Login→ POST /delivery/login
👑 Admin         → /admin/...
📱 User          → /app/...
🚴 Delivery      → /delivery/...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    """)
    yield
    # Shutdown
    logger.info("ALTPrint shutting down")

# ── APP ───────────────────────────────────────────────────────────────────
app = FastAPI(
    title="ALTPrint Mobile Backend",
    version="8.0.0",
    description="""
## ALTPrint — Printing Service Mobile Backend

### URL Structure
| URL | Who | Access |
|-----|-----|--------|
| `/admin/...` | **Admin (Boss)** | Full control — zones, hubs, users, all orders, features, delivery partners |
| `/app/...` | **Mobile Users** | Own orders, files, payments, delivery tracking |
| `/delivery/...` | **Delivery Partners** | Assigned orders, live location update |
| `/agent/...` | **Shop Staff** | Zone-based order processing |

### Auth Flow
```
POST /app/login → copy access_token → click 🔒 Authorize → paste token
POST /delivery/login → separate token for delivery partners
```
""",
    lifespan=lifespan,
)

# ── CORS (for mobile app) ─────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── GLOBAL ERROR HANDLER ──────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_error_handler(request: Request, exc: Exception):
    logger.error(f"[{request.method} {request.url.path}]: {exc}")
    return JSONResponse(
        status_code=500,
        content={"success": False, "error": "Internal server error"}
    )

# ── ROUTES ────────────────────────────────────────────────────────────────
app.include_router(auth_router)           # /app/register  /app/login  /app/me
app.include_router(order_router)          # /app/create-order  /app/orders
app.include_router(file_router)           # /app/upload-file  /app/file/{id}
app.include_router(payment_router)        # /app/payment/...
app.include_router(admin_router)          # /admin/...
app.include_router(router_admin_delivery) # /admin/delivery-partners  /admin/create-delivery-partner
app.include_router(router_delivery)       # /delivery/login  /delivery/my-orders  /delivery/update-location

# ── TRACKING ROUTE (user sees partner live location) ─────────────────────
from fastapi import Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.middleware.auth import get_current_user
from app.models import User, PrintOrder
from app.routes.delivery_routes import get_delivery_tracking

@app.get("/app/track-order/{order_id}", tags=["App — User"])
def track_order(
    order_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    User tracks their delivery in real time.
    Returns delivery partner name, phone number, and live GPS coordinates.
    Mobile app uses lat/lng to show partner on map (Google Maps / MapBox).
    """
    return get_delivery_tracking(order_id, user, db)

# ── HEALTH CHECK ──────────────────────────────────────────────────────────
@app.get("/health", tags=["Public"])
def health():
    return {"status": "ok", "version": "8.0.0", "service": "ALTPrint Backend"}

@app.get("/", tags=["Public"])
def root():
    return {
        "service": "ALTPrint Mobile Backend",
        "version": "8.0.0",
        "docs": "/docs",
        "health": "/health"
    }

# ── SWAGGER SECURITY SCHEME ───────────────────────────────────────────────
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
        }
    }
    for path in schema.get("paths", {}).values():
        for operation in path.values():
            operation.setdefault("security", [{"BearerAuth": []}])
    app.openapi_schema = schema
    return schema

app.openapi = custom_openapi

# ── RUN ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
